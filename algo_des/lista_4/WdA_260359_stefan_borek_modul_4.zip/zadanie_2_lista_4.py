class Tree:  # Klasa reprezentująca drzewo

    def __init__(self, data=None, left=None, right=None):
        self.data = data
        self.right = right
        self.left = left

    def __str__(self):
        return str(self.data)


class Node:  # Klasa reprezentująca węzeł

    def __init__(self, data=None, next=None):
        self.data = data
        self.next = next


class Linkedlist:  # Klasa reprezentująca całą listę jednokierunkową

    def __init__(self):
        self.length = 0
        self.head = None
        self.tail = None

    def is_empty(self):
        return self.length == 0

    def count(self):
        return self.length

    def insert_head(self, node):
        if self.length == 0:
            self.head = self.tail = node
        else:
            node.next = self.head
            self.head = node
        self.length += 1

    def insert_tail(self, node):
        if self.length == 0:
            self.head = self.tail = node
        else:
            self.tail.next = node
            self.tail = node
        self.length += 1

    def print_list(self):
        temp = self.head
        while temp:
            print(temp.data)
            temp = temp.next


def dfs(top, kolejka):
    if top is None:
        return
    kolejka.insert_tail(Node(top))
    dfs(top.left, kolejka)
    dfs(top.right, kolejka)


def find_node(kolejka, to_visit, value):
    while kolejka:
        for n in kolejka:
            to_visit.append(n)
        kolejka = []
        for node in to_visit:
            if node.data == value:
                kol = Linkedlist()
                dfs(node, kol)
                print('Nowe drzewo DFS:')
                kol.print_list()
                return
            if node.left:
                kolejka.append(node.left)
            if node.right:
                kolejka.append(node.right)
        to_visit = []



# Ręczne budowanie większego drzewa
root = Tree(1)
root.left = Tree(2)
root.right = Tree(3)
root.left.left = Tree(4)
root.left.right = Tree(5)
root.right.left = Tree(6)
root.right.right = Tree(7)
root.left.left.left = Tree(8)
root.left.left.right = Tree(9)
root.left.right.left = Tree(10)
root.left.right.right = Tree(11)

l_1 = [root]
visit = []
find_node(l_1, visit, 2)
